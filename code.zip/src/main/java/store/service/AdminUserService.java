package store.service;

import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import store.entity.AdminUser;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

public interface AdminUserService {

     //根据id查询
    AdminUser findById(int id);


    //分页查询
    Page<AdminUser> findAll(Pageable pageable);

    //按条件查询
    List<AdminUser> findAllExample(Example<AdminUser> example);

    //更新
    void update(AdminUser adminUser);

    //新增
    int create(AdminUser adminUser);

    //删除
    void delById(int id);

    //检测登陆
    AdminUser checkLogin(HttpServletRequest request,String username, String pwd);

}
