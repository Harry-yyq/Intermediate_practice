package store.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import store.dao.OrderDao;
import store.dao.OrderItemDao;
import store.dao.ProductDao;
import store.dao.UserDao;
import store.entity.Order;
import store.entity.OrderItem;
import store.entity.Product;
import store.entity.User;
import store.service.OrderService;
import store.service.ShopCartService;
import store.service.exception.LoginException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.DecimalFormat;
import java.util.Date;
import java.util.List;

@Service
public class OrderServiceImpl implements OrderService {
    @Autowired
    private OrderDao orderDao;
    @Autowired
    private OrderItemDao orderItemDao;
    @Autowired
    private ProductDao productDao;
    @Autowired
    private ShopCartService shopCartService;
    @Autowired
    private UserDao userDao;


    @Override
    public Order findById(int id) {
        return orderDao.getOne(id);
    }

    @Override
    public Page<Order> findAll(Pageable pageable) {
        return orderDao.findAll(pageable);
    }

    @Override
    public List<Order> findAllExample(Example<Order> example) {
        return orderDao.findAll(example);
    }

    @Override
    public void update(Order order) {
        orderDao.save(order);
    }

    @Override
    public int create(Order order) {
        Order order1 = orderDao.save(order);
        return order1.getId();
    }

    @Override
    public void delById(int id) {
        orderDao.delete(id);
    }

    //查询订单项详情
    @Override
    public List<OrderItem> findItems(int orderId) {
        List<OrderItem> list = orderItemDao.findByOrderId(orderId);
        for (OrderItem orderItem : list) {
            Product product = productDao.findOne(orderItem.getProductId());
            orderItem.setProduct(product);
        }
        return list;
    }

    //更改订单状态
    @Override
    public void updateStatus(int id, int status) {
        Order order = orderDao.findOne(id);
        order.setState(status);
        orderDao.save(order);
    }

    //查找用户的订单列表
    @Override
    public List<Order> findUserOrder(HttpServletRequest request) {
        //从session中获取登录用户的id，查找他的订单
        Object user = request.getSession().getAttribute("user");
        if (user == null)
            throw new LoginException("请登录！");
        User loginUser = (User) user;
        List<Order> orders = orderDao.findByUserId(loginUser.getId());
        return orders;
    }

    //支付
    @Override
    public void pay(int orderId,HttpServletRequest request) {
        //更改状态为待发货
        Order order = orderDao.findOne(orderId);
        if (order == null)
            throw new RuntimeException("订单不存在");
        orderDao.updateState(STATE_WAITE_SEND,order.getId());

        //增加用户积分,1元换1积分
        Object user = request.getSession().getAttribute("user");
        User loginUser = (User) user;
        User u = userDao.findOne(loginUser.getId());
        String str = new DecimalFormat("0").format(order.getTotal());
        u.setIntegral(u.getIntegral() + Integer.parseInt(str));
        userDao.save(u);

        request.getSession().setAttribute("user",u);

    }

    //提交订单
    @Override
    @Transactional
    public void submit(String name, String phone, String addr, HttpServletRequest request, HttpServletResponse response) throws Exception {
        Object user = request.getSession().getAttribute("user");
        if (user == null)
            throw new LoginException("请登录！");
        User loginUser = (User) user;
        Order order = new Order();
        order.setName(name);
        order.setPhone(phone);
        order.setAddr(addr);
        order.setOrderTime(new Date());
        order.setUserId(loginUser.getId());
        order.setState(STATE_NO_PAY);
        List<OrderItem> orderItems = shopCartService.listCart(request);
        Integer total = 0;
        order.setTotal(total);
        order = orderDao.save(order);
        for (OrderItem orderItem : orderItems) {
            orderItem.setOrderId(order.getId());
            total += orderItem.getSubTotal();
            orderItemDao.save(orderItem);
        }
        order.setTotal(total);

        //获取当前用户积分,抵扣
        User u = userDao.findOne(loginUser.getId());
        Integer integral = u.getIntegral();
        Integer actualTotal = total - integral/100;

        //若积分可兑换 大于 订单总价
        if(actualTotal<0){
            actualTotal=0;
        }
        order.setActualTotal(actualTotal);
        orderDao.save(order);

        //如支付时扣积分，扣除用户表里的积分
        if(integral/100 >= 1){

            Integer laveIntegral = 0;
            if(total>integral/100){
                //总价 > 积分价值,如199
                laveIntegral = integral % 100;
            }else{
                //总价 <= 积分价值
                laveIntegral = integral - total*100;
            }
            u.setIntegral(laveIntegral);
            userDao.save(u);
        }


        request.getSession().setAttribute("user",u);

        //重定向到订单列表页面
        response.sendRedirect("/mall/order/toList.html");
    }

    //确认收货
    @Override
    public void receive(int orderId) {
        Order order = orderDao.findOne(orderId);
        if (order == null)
            throw new RuntimeException("订单不存在");
        orderDao.updateState(STATE_COMPLETE,order.getId());
    }
}
