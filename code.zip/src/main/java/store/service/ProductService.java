package store.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import store.entity.Product;

import java.util.List;

public interface ProductService {
    //根据id查询
    Product findById(int id);

    //分页查询
    Page<Product> findAll(Pageable pageable);

    //查找热门商品
    List<Product> findHotProduct();

    //查找最新商品
    List<Product> findNewProduct(Pageable pageable);

    //根据一级分类查找商品
    List<Product> findByCid(int cid,Pageable pageable);

    //根据二级分类查找商品
    List<Product> findByCsid(int csid,Pageable pageable);

    //更新
    void update(Product product);

    //新建
    int create(Product product);

    //删除
    void delById(int id);

}
