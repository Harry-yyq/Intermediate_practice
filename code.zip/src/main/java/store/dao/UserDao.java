package store.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import store.entity.User;

import java.util.List;

public interface UserDao extends JpaRepository<User, Integer> {
    //根据用户名，密码查询用户
    User findByUsernameAndPassword(String username, String password);

   //根据用户名查询用户
    List<User> findByUsername(String username);
}
